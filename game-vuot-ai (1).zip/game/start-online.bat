@echo off
chcp 65001 >nul
set TUNNEL=1
node server.js
pause
