const IMG={s:'stand.png',w:'walk.png'};
function renderPlayers(st,list,selfId){
  const seen={};
  list.forEach(p=>{seen[p.id]=1;let d=st.map[p.id];
    if(!d){d=document.createElement('div');d.className='pl';d.innerHTML='<b></b><img>';st.el.appendChild(d);st.map[p.id]=d;d.lastChild.style.filter='hue-rotate('+p.col+'deg)'}
    d.style.left=p.x+'%';d.style.top=p.y+'%';d.style.zIndex=Math.round(p.y*10);
    d.firstChild.textContent=p.n+(p.id===selfId?' (bạn)':'');
    d.lastChild.src=p.mv?IMG.w:IMG.s;d.lastChild.style.transform=p.f<0?'scaleX(-1)':''});
  for(const id in st.map)if(!seen[id]){st.map[id].remove();delete st.map[id]}
}
function rankHTML(list){return '<table>'+list.slice().sort((a,b)=>b.s-a.s).map((p,i)=>`<tr><td>${i+1}</td><td>${p.n}</td><td style="text-align:right"><b>${p.s}</b></td></tr>`).join('')+'</table>'}
async function api(u,b){const r=await fetch(u,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return r.json()}
