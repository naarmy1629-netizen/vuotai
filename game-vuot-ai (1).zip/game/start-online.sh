#!/bin/sh
cd "$(dirname "$0")"
TUNNEL=1 node server.js
