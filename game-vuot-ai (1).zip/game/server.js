// Server game vượt ải - không cần cài thêm thư viện, chỉ cần Node.js
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os');
const PORT=process.env.PORT||3000, PUB=path.join(__dirname,'public');
const CODE=(process.env.GAME_CODE||Math.random().toString(36).slice(2,6)).toUpperCase();
const COLS=[0,160,260,60,310,110,210],MIME={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg'};
const players={},streams={},hosts=new Set(),active={};let lbOn=true,dirty=true,cnt=0;
const sh=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const lan=()=>{for(const l of Object.values(os.networkInterfaces()))for(const i of l)if(i.family==='IPv4'&&!i.internal)return i.address;return'localhost'};
let BASE=process.env.PUBLIC_URL||`http://${lan()}:${PORT}`;
const PIN=process.env.HOST_PIN||String(1000+Math.random()*9000|0);
const send=(id,o)=>streams[id]&&streams[id].write('data:'+JSON.stringify(o)+'\n\n');
const pub=p=>({id:p.id,n:p.n,x:p.x,y:p.y,f:p.f,mv:p.mv,s:p.s,col:p.col,man:p.man});
function nextQ(p){
  if(p.qi>=p.q.length){p.cur=null;return send(p.id,{t:'done',score:p.s})}
  const it=p.q[p.qi],o=sh(it.o.map((t,k)=>({t,k})));
  p.cur={right:o.findIndex(x=>x.k===it.c)};
  send(p.id,{t:'q',ai:p.ai,n:p.qi+1,total:p.q.length,q:it.q,o:o.map(x=>x.t)});
}
function post(p,j,res){
  if(p.startsWith('/api/host/')&&String(j.pin)!==PIN){res.writeHead(200,{'content-type':'application/json'});return res.end('{"err":"Sai PIN"}')}
  let r={ok:1};const pl=players[j.id];
  if(p==='/api/join'){
    if(String(j.code||'').toUpperCase()!==CODE)r={err:'Sai mã game'};
    else{const man=Math.min(6,Math.max(1,+j.man||1)),id=Math.random().toString(36).slice(2,10);
      players[id]={id,n:String(j.name||'Bạn').slice(0,14),man,x:20+Math.random()*60,y:55+Math.random()*35,f:1,mv:0,s:0,col:COLS[cnt++%COLS.length],q:[],qi:0,cur:null};
      dirty=true;r={id,x:players[id].x,y:players[id].y,col:players[id].col}}
  }else if(p==='/api/move'&&pl){
    pl.x=Math.min(97,Math.max(3,+j.x));pl.y=Math.min(98,Math.max(35,+j.y));pl.f=j.f<0?-1:1;pl.mv=j.mv?1:0;dirty=true;
  }else if(p==='/api/answer'&&pl&&pl.cur){
    const ok=+j.k===pl.cur.right;pl.s+=ok?1:-1;const right=pl.cur.right;pl.cur=null;pl.qi++;dirty=true;
    send(pl.id,{t:'res',ok,right,score:pl.s});setTimeout(()=>nextQ(pl),900);
  }else if(p==='/api/host/activate'){
    const man=+j.man,ai=+j.ai;active[man]=ai;
    let bank={};try{bank=JSON.parse(fs.readFileSync(path.join(__dirname,'questions.json'),'utf8'))}catch(e){}
    const list=(bank[man]&&bank[man][ai])||bank.default||[];
    for(const q of Object.values(players))if(q.man===man){q.ai=ai;q.q=sh(list).slice(0,10);q.qi=0;nextQ(q)}
    dirty=true;
  }else if(p==='/api/host/lb'){lbOn=!!j.on;dirty=true}
  res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(r));
}
function sse(res){res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache',connection:'keep-alive'});res.write('retry: 1500\n\n')}
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),p=u.pathname;
  if(req.method==='POST'){let b='';for await(const c of req)b+=c;let j={};try{j=JSON.parse(b)}catch{}return post(p,j,res)}
  if(p==='/api/stream'){const id=u.searchParams.get('id');if(!players[id]){res.writeHead(404);return res.end()}
    sse(res);streams[id]=res;clearTimeout(players[id].gone);dirty=true;
    req.on('close',()=>{if(streams[id]===res){delete streams[id];if(players[id])players[id].gone=setTimeout(()=>{delete players[id];dirty=true},30000)}});return}
  if(p==='/api/host-stream'){if(u.searchParams.get('pin')!==PIN){res.writeHead(403);return res.end()}sse(res);hosts.add(res);dirty=true;req.on('close',()=>hosts.delete(res));return}
  const f=p==='/'?'/index.html':p==='/host'?'/host.html':p,fp=path.join(PUB,path.normalize(f));
  if(!fp.startsWith(PUB)||!fs.existsSync(fp)||fs.statSync(fp).isDirectory()){res.writeHead(404);return res.end('404')}
  res.writeHead(200,{'content-type':MIME[path.extname(fp)]||'application/octet-stream'});fs.createReadStream(fp).pipe(res);
}).listen(PORT,'0.0.0.0',()=>console.log(`\n=== GAME VƯỢT ẢI ĐÃ CHẠY ===\nMã game: ${CODE}\nMàn hình Host: http://localhost:${PORT}/host?pin=${PIN}   (PIN: ${PIN})\nChơi khác Wi-Fi: dùng start-online.bat\n`));
setInterval(()=>{
  if(!dirty)return;dirty=false;
  const all=Object.values(players),by={};all.forEach(p=>(by[p.man]=by[p.man]||[]).push(pub(p)));
  for(const id in streams)send(id,{t:'s',lb:lbOn,pl:by[players[id].man]||[]});
  hosts.forEach(h=>h.write('data:'+JSON.stringify({t:'h',code:CODE,base:BASE,lb:lbOn,active,pl:all.map(pub)})+'\n\n'));
},100);

if(process.env.TUNNEL){
  const {spawn}=require('child_process');let shown=false;
  const c=spawn('ssh',['-T','-o','StrictHostKeyChecking=accept-new','-o','ServerAliveInterval=30','-o','ExitOnForwardFailure=yes','-R','80:localhost:'+PORT,'nokey@localhost.run']);
  const rd=d=>{const m=String(d).match(/https:\/\/[a-z0-9-]+\.lhr\.life/);
    if(m&&!shown){shown=true;BASE=m[0];console.log(`\n>>> LINK CÔNG KHAI: ${BASE}\n>>> MỞ HOST BẰNG LINK NÀY: ${BASE}/host?pin=${PIN}\n>>> Gửi QR trên trang Host cho người chơi. Không cần mật khẩu.\n`)}};
  c.stdout.on('data',rd);c.stderr.on('data',rd);
  c.on('error',()=>console.log('Không chạy được lệnh ssh. Gõ "ssh -V" trong cmd để kiểm tra (xem HUONG-DAN.txt).'));
  c.on('close',()=>console.log('Tunnel đã đóng. Tắt cửa sổ này và chạy lại start-online.bat (link sẽ đổi).'));
}
